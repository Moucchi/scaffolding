package org.moucchi;

import com.google.gson.GsonBuilder;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Scanner;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class HandyManUtils {
    public HandyManUtils() {
    }

    public static void extractDir(String sourcedir, String target) throws IOException {
        
            byte[] buffer = new byte[4096];
            File file = new File(sourcedir);

            try {
                Throwable var44 = null;
                Object var8 = null;

                try {
                    ZipInputStream zis = new ZipInputStream(new FileInputStream(file));

                    try {
                        ZipEntry ze = zis.getNextEntry();

                        while(ze != null) {
                            String fileName = ze.getName();
                            File newFile = new File(target + File.separator + fileName);
                            if (ze.isDirectory()) {
                                newFile.mkdir();
                                zis.closeEntry();
                                ze = zis.getNextEntry();
                            } else {
                                Throwable var13 = null;
                                Object var14 = null;

                                try {
                                    FileOutputStream fos = new FileOutputStream(newFile);

                                    int len;
                                    try {
                                        while((len = zis.read(buffer)) > 0) {
                                            fos.write(buffer, 0, len);
                                        }
                                    } finally {
                                        if (fos != null) {
                                            fos.close();
                                        }

                                    }
                                } catch (Throwable var38) {
                                    if (var13 == null) {
                                        var13 = var38;
                                    } else if (var13 != var38) {
                                        var13.addSuppressed(var38);
                                    }

                                    throw var13;
                                }

                                zis.closeEntry();
                                ze = zis.getNextEntry();
                            }
                        }
                    } finally {
                        if (zis != null) {
                            zis.close();
                        }

                    }
                } catch (Throwable var40) {
                    if (var44 == null) {
                        var44 = var40;
                    } else if (var44 != var40) {
                        var44.addSuppressed(var40);
                    }

                    throw var44;
                }
            } catch (Throwable var41) {
                var41.printStackTrace();
            }

        
    }

    public static void extractDirFromInsideJar(Class<?> c, String sourcedir, String target) throws IOException {
        
            byte[] buffer = new byte[4096];

            try {
                Throwable var43 = null;

                try {
                    ZipInputStream zis = new ZipInputStream(c.getResourceAsStream(sourcedir));

                    try {
                        ZipEntry ze = zis.getNextEntry();

                        while(ze != null) {
                            String fileName = ze.getName();
                            File newFile = new File(target + File.separator + fileName);
                            if (ze.isDirectory()) {
                                newFile.mkdir();
                                zis.closeEntry();
                                ze = zis.getNextEntry();
                            } else {
                                Throwable var13 = null;
                                Object var14 = null;

                                try {
                                    FileOutputStream fos = new FileOutputStream(newFile);

                                    int len;
                                    try {
                                        while((len = zis.read(buffer)) > 0) {
                                            fos.write(buffer, 0, len);
                                        }
                                    } finally {
                                        if (fos != null) {
                                            fos.close();
                                        }

                                    }
                                } catch (Throwable var38) {
                                    if (var13 == null) {
                                        var13 = var38;
                                    } else if (var13 != var38) {
                                        var13.addSuppressed(var38);
                                    }

                                    throw var13;
                                }

                                zis.closeEntry();
                                ze = zis.getNextEntry();
                            }
                        }
                    } finally {
                        if (zis != null) {
                            zis.close();
                        }

                    }
                } catch (Throwable var40) {
                    if (var43 == null) {
                        var43 = var40;
                    } else if (var43 != var40) {
                        var43.addSuppressed(var40);
                    }

                    throw var43;
                }
            } catch (Throwable var41) {
                var41.printStackTrace();
            }

        
    }

    public static String getFileContent(String filePath) throws Throwable {
        
            String content = "";
            File file = new File(filePath);
            Throwable var17 = null;
            Object var7 = null;

            try {
                Scanner reader = new Scanner(file);

                try {
                    while(reader.hasNextLine()) {
                        content = content + reader.nextLine() + "\n";
                    }
                } finally {
                    if (reader != null) {
                        reader.close();
                    }

                }

                return content;
            } catch (Throwable var14) {
                if (var17 == null) {
                    var17 = var14;
                } else if (var17 != var14) {
                    var17.addSuppressed(var14);
                }

                throw var17;
            }
        
    }

    public static String getFileContentFromInsideJar(Class<?> c, String filePath) throws Throwable {
        
            String content = "";
            Throwable var16 = null;

            try {
                Scanner reader = new Scanner(c.getResourceAsStream(filePath));

                try {
                    while(reader.hasNextLine()) {
                        content = content + reader.nextLine() + "\n";
                    }
                } finally {
                    if (reader != null) {
                        reader.close();
                    }

                }

                return content;
            } catch (Throwable var14) {
                if (var16 == null) {
                    var16 = var14;
                } else if (var16 != var14) {
                    var16.addSuppressed(var14);
                }

                throw var16;
            }
        
    }

    public static void copyFileFromInsideJar(Class<?> c, String source, String target) throws Throwable {
        
            Path targetPath = Path.of(target);
            Throwable var17 = null;

            try {
                InputStream stream = c.getResourceAsStream(source);

                try {
                    Files.copy(stream, targetPath, new CopyOption[]{StandardCopyOption.REPLACE_EXISTING});
                } finally {
                    if (stream != null) {
                        stream.close();
                    }

                }

            } catch (Throwable var15) {
                if (var17 == null) {
                    var17 = var15;
                } else if (var17 != var15) {
                    var17.addSuppressed(var15);
                }

                throw var17;
            }
       
    }

    public static void overwriteFileContent(String filePath, String content) throws Throwable {
        
            File file = new File(filePath);
            Throwable var16 = null;

            try {
                FileWriter writer = new FileWriter(file, false);

                try {
                    writer.write(content);
                } finally {
                    if (writer != null) {
                        writer.close();
                    }

                }

            } catch (Throwable var14) {
                if (var16 == null) {
                    var16 = var14;
                } else if (var16 != var14) {
                    var16.addSuppressed(var14);
                }

                throw var16;
            }
        
    }

    public static String minStart(String s) {
        return s.replaceFirst(String.valueOf(s.charAt(0)), String.valueOf(s.charAt(0)).toLowerCase());

    }

    public static String majStart(String s) {
        return s.replaceFirst(String.valueOf(s.charAt(0)), String.valueOf(s.charAt(0)).toUpperCase());

    }

    public static String toCamelCase(String s) {
       
            String newString = "";
            boolean snakeTrail = false;

            for(int i = 0; i < s.toCharArray().length; ++i) {
                String c = String.valueOf(s.charAt(i));
                if (snakeTrail) {
                    c = majStart(c);
                    snakeTrail = false;
                }

                if (c.equals("_")) {
                    c = "";
                    snakeTrail = true;
                }

                newString = newString + c;
            }

            return newString;
       
    }

    public static <T> T fromJson(Class<T> clazz, String json) {
       
            GsonBuilder builder = (new GsonBuilder()).registerTypeAdapter(LocalDate.class, new LocalDateTypeAdapter());
            builder = builder.registerTypeAdapter(LocalTime.class, new LocalTimeTypeAdapter());
            builder = builder.registerTypeAdapter(LocalDateTime.class, new LocalDateTimeTypeAdapter());
            T object = builder.create().fromJson(json, clazz);
            return object;
        
    }

    public static String toJson(Object source) {
        
            GsonBuilder builder = (new GsonBuilder()).registerTypeAdapter(LocalDate.class, new LocalDateTypeAdapter());
            builder = builder.registerTypeAdapter(LocalTime.class, new LocalTimeTypeAdapter());
            builder = builder.registerTypeAdapter(LocalDateTime.class, new LocalDateTimeTypeAdapter());
            String object = builder.create().toJson(source);
            return object;
       
    }

    public static void createFile(String filePath) throws IOException {
        
            filePath = filePath.replace("\\", "/");
            String filename = "";
            String currentChar = "";

            File file;
            for(int i = 0; i < filePath.toCharArray().length; ++i) {
                currentChar = String.valueOf(filePath.charAt(i));
                if (currentChar.equals("/") && !filename.equals(".") && !filename.isEmpty()) {
                    file = new File(filename);
                    file.mkdir();
                }

                filename = filename + currentChar;
            }

            file = new File(filename);
            file.createNewFile();
      
    }

    public static void createDirectory(String filePath) throws IOException {
        
            String filename = "";
            String currentChar = "";

            File file;
            for(int i = 0; i < filePath.toCharArray().length; ++i) {
                currentChar = String.valueOf(filePath.charAt(i));
                if (currentChar.equals("/") && (!filename.equals(".") || !filename.isEmpty())) {
                    file = new File(filename);
                    file.mkdir();
                }

                filename = filename + currentChar;
            }

            file = new File(filename);
            file.mkdir();
        
    }

    public static String formatReadable(String s) {
        
            String newString = s.replace("_", " ");
            char[] characts = newString.toCharArray();
            String newWord = "";

            for(int i = 0; i < characts.length; ++i) {
                if (Character.isUpperCase(characts[i])) {
                    newWord = newWord + " ";
                    newWord = newWord + String.valueOf(Character.toLowerCase(characts[i]));
                } else {
                    newWord = newWord + characts[i];
                }
            }

            newWord = majStart(newWord);
            return newWord;
       
    }

    public static String minAll(String s) {
        
            char[] characts = s.toCharArray();
            String newWord = "";

            for(int i = 0; i < characts.length; ++i) {
                if (Character.isUpperCase(characts[i])) {
                    newWord = newWord + String.valueOf(Character.toLowerCase(characts[i]));
                } else {
                    newWord = newWord + characts[i];
                }
            }

            return newWord;
        
    }

    public static <T> T parse(Class<T> clazz, String value) {
        return fromJson(clazz, "\"" + value + "\"");

    }
}
